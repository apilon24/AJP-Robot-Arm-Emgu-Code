﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloEmgu1
{
    public partial class Form1 : Form
    {
        VideoCapture _capture;                              //Start camera
        Thread _captureThread;
        SerialPort arduinoSerial = new SerialPort();        //Create Serial Communication
        Thread serialMonitoringThread;                      


        bool enableCoordinateSending = true;

        byte[] buffer = new byte[4];                        //Create the byte to send to Arduino


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _captureThread.Abort();
            serialMonitoringThread.Abort();                 //Close Serial Data and Camera when the tab closes
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // create the capture object and processing thread
            _capture = new VideoCapture(1);
            _captureThread = new Thread(DisplayWebcam);             //initialize Webcam
            _captureThread.Start();

            try
            {
                arduinoSerial.PortName = "COM4";
                arduinoSerial.BaudRate = 115200;
                arduinoSerial.Open();

                arduinoSerial.DiscardOutBuffer();                           //Communicate to Arduino
                arduinoSerial.DiscardInBuffer();
                serialMonitoringThread = new Thread(MonitorSerialData);
                serialMonitoringThread.Start();


                arduinoSerial.DataReceived += ArduinoSerial_DataReceived;

                


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Initializing COM port");
                Close();

            }

        }
        private void DisplayWebcam()
        {
            while (_capture.IsOpened)
            {
                // frame maintenance

                // resize to PictureBox aspect ratio



                // display the image in the PictureBox

                // frame maintenance
                Mat sourceFrame = _capture.QueryFrame();
                Image<Bgr, Byte> buffer_im = sourceFrame.ToImage<Bgr, Byte>();
                buffer_im.ROI = new Rectangle(160, 115, sourceFrame.Width - 320, sourceFrame.Height - 230);     //Crop Camera Frame
                sourceFrame = buffer_im.Copy().Mat;

                // resize to PictureBox aspect ratio
                int newHeight = (sourceFrame.Size.Height * sourcePictureBox.Size.Width) / sourceFrame.Size.Width;
                Size newSize = new Size(sourcePictureBox.Size.Width, newHeight);                                //Form to the Picture Box
                CvInvoke.Resize(sourceFrame, sourceFrame, newSize);
                // display the image in the source PictureBox
                
                Invoke(new Action(() =>
                {
                    sourcePictureBox.Image = sourceFrame.Bitmap;
                }));


                // Sample for gaussian blur:
                var blurredImage = new Mat();
                        var cannyImage = new Mat();
                        var decoratedImage = new Mat();
                //CvInvoke.GaussianBlur(sourceFrame, blurredImage, new Size(11, 11), 0);
                // convert to B/W
                CvInvoke.CvtColor(sourceFrame, blurredImage, ColorConversion.Bgr2Gray);
                        CvInvoke.Threshold(blurredImage, blurredImage, 190, 255, ThresholdType.Binary);     //Convert to B/W
                // apply canny:
                // NOTE: Canny function can frequently create duplicate lines on the same shape
                // depending on bur amount and threshold values, some tweaking might be needed.
                // You might also find that not using Canny and instead using FindContours on
                // a binary-threshold image is more accurate.
                //CvInvoke.Canny(blurredImage, cannyImage, 150, 255);
                // make a copy of the canny image, convert it to color for decorating:
                //CvInvoke.CvtColor(cannyImage, decoratedImage, typeof(Gray), typeof(Bgr));
                // find contours:

                CvInvoke.CvtColor(blurredImage, decoratedImage, typeof(Gray), typeof(Bgr));
                roiPictureBox.Image = blurredImage.Bitmap;
                        using (VectorOfVectorOfPoint contourssmall = new VectorOfVectorOfPoint())
                        {
                            // Build list of contours
                            CvInvoke.FindContours(blurredImage, contourssmall, null, RetrType.List,
        ChainApproxMethod.ChainApproxSimple);
                    int j = 0;
                    int squarecounter = 0;
                    int trianglecounter = 0;
                    int zoneOfShape = 0;
                    char shape;
                            for (int i = 0; i < contourssmall.Size; i++)
                            {
                                double area = CvInvoke.ContourArea(contourssmall[i]); //Find areas of contours

                        if (area < 4500 && area > 1200)         //Separates the Junk Contours
                        {
                            VectorOfPoint contourss = contourssmall[i];
                            if (area > 2100)
                            {
                                CvInvoke.Polylines(decoratedImage, contourss, true, new Bgr(Color.Red).MCvScalar);
                                squarecounter++;                                    //Label as Square
                                shape = 'S';
                            }
                            else
                            {
                                CvInvoke.Polylines(decoratedImage, contourss, true, new Bgr(Color.Green).MCvScalar);
                                trianglecounter++;                                  //Label as Triangle
                                shape = 'T';
                            }
                            j++;
                            Rectangle boundingBox = CvInvoke.BoundingRectangle(contourssmall[i]);
                            Point center = new Point(boundingBox.X + boundingBox.Width / 2, boundingBox.Y + boundingBox.Height / 2);    //Finds center point of the bounding box
                            var info = new string[] { $"Area: {area}", $"Position: {center.X}, {center.Y}"};                            //Assign to center.x and center.y
                            if(center.X > 40 && center.X <= 60)                 //uses the centerpoint to assign the shape to a certain zone.
                            {
                                if(center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 154;
                                }
                                else if(center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 153;
                                }
                                else if(center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 152;
                                }
                                else if(center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 151;
                                }
                                else if(center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 150;
                                }
                                else if(center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 149;
                                }
                                else if(center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 148;
                                }
                                else if(center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 147;
                                }
                                else if(center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 146;
                                }
                                else if(center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 145;
                                }
                                else
                                {
                                    zoneOfShape = 144;
                                }
                            }
                            else if(center.X > 60 && center.X <= 80)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 143;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 142;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 141;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 140;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 139;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 138;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 137;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 136;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 135;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 134;
                                }
                                else
                                {
                                    zoneOfShape = 133;
                                }
                            }
                            else if(center.X > 80 && center.X <= 100)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 132;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 131;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 130;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 129;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 128;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 127;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 126;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 125;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 124;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 123;
                                }
                                else
                                {
                                    zoneOfShape = 122;
                                }
                            }
                            else if(center.X > 100 && center.X <= 120)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 121;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 120;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 119;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 118;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 117;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 116;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 115;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 114;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 113;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 112;
                                }
                                else
                                {
                                    zoneOfShape = 111;
                                }
                            }
                            else if(center.X > 120 && center.X <= 140)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 110;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 109;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 108;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 107;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 106;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 105;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 104;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 103;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 102;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 101;
                                }
                                else
                                {
                                    zoneOfShape = 100;
                                }
                            }
                            else if(center.X > 140 && center.X <= 160)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 99;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 98;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 97;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 96;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 95;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 94;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 93;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 92;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 91;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 90;
                                }
                                else
                                {
                                    zoneOfShape = 89;
                                }
                            }
                            else if(center.X > 160 && center.X <= 180)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 88;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 87;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 86;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 85;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 84;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 83;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 82;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 81;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 80;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 79;
                                }
                                else
                                {
                                    zoneOfShape = 78;
                                }
                            }
                            else if(center.X > 180 && center.X <= 200)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 77;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 76;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 75;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 74;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 73;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 72;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 71;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 70;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 69;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 68;
                                }
                                else
                                {
                                    zoneOfShape = 67;
                                }
                            }
                            else if(center.X > 200 && center.X <= 220)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 66;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 65;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 64;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 63;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 62;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 61;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 60;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 59;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 58;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 57;
                                }
                                else
                                {
                                    zoneOfShape = 56;
                                }
                            }
                            else if(center.X > 220 && center.X <= 240)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 55;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 54;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 53;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 52;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 51;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 50;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 49;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 48;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 47;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 46;
                                }
                                else
                                {
                                    zoneOfShape = 45;
                                }
                            }
                            else if(center.X > 240 && center.X <= 260)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 44;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 43;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 42;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 41;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 40;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 39;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 38;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 37;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 36;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 35;
                                }
                                else
                                {
                                    zoneOfShape = 34;
                                }
                            }
                            else if(center.X > 260 && center.X <= 280)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 33;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 32;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 31;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 30;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 29;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 28;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 27;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 26;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 25;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 24;
                                }
                                else
                                {
                                    zoneOfShape = 23;
                                }
                            }
                            else if(center.X > 280 && center.X <= 300)
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 22;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 21;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 20;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 19;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 18;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 17;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 16;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 15;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 14;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 13;
                                }
                                else
                                {
                                    zoneOfShape = 12;
                                }
                            }
                            else
                            {
                                if (center.Y > 21 && center.Y <= 42)
                                {
                                    zoneOfShape = 11;
                                }
                                else if (center.Y > 42 && center.Y <= 63)
                                {
                                    zoneOfShape = 10;
                                }
                                else if (center.Y > 63 && center.Y <= 84)
                                {
                                    zoneOfShape = 9;
                                }
                                else if (center.Y > 84 && center.Y <= 105)
                                {
                                    zoneOfShape = 8;
                                }
                                else if (center.Y > 105 && center.Y <= 126)
                                {
                                    zoneOfShape = 7;
                                }
                                else if (center.Y > 126 && center.Y <= 147)
                                {
                                    zoneOfShape = 6;
                                }
                                else if (center.Y > 147 && center.Y <= 168)
                                {
                                    zoneOfShape = 5;
                                }
                                else if (center.Y > 168 && center.Y <= 189)
                                {
                                    zoneOfShape = 4;
                                }
                                else if (center.Y > 189 && center.Y <= 210)
                                {
                                    zoneOfShape = 3;
                                }
                                else if (center.Y > 210 && center.Y <= 231)
                                {
                                    zoneOfShape = 2;
                                }
                                else
                                {
                                    zoneOfShape = 1;
                                }
                            }
                            CvInvoke.Circle(decoratedImage, center, 1, new Bgr(Color.Yellow).MCvScalar);
                            WriteMultilineText(decoratedImage, info, new Point(center.X, boundingBox.Bottom + 12));
                            byte[] buffer = new byte[4] {
                                Encoding.ASCII.GetBytes("<")[0],
                                Convert.ToByte(zoneOfShape),                //make the array to send to the Arduino
                                Convert.ToByte(shape),
                                Encoding.ASCII.GetBytes(">")[0]
                                };
                            arduinoSerial.Write(buffer, 0, 4);              //send the array to the Arduino
                            }



                        Invoke(new Action(() =>
                        {
                            contourPictureBox.Image = decoratedImage.Bitmap;
                        }));
                        
                    }

                            //MessageBox.Show($"There are {j} contours detected\nThere are {squarecounter} squares detected\nThere are {trianglecounter} triangles detected");
                            
                            
                }
                        // output images:
                        sourcePictureBox.Image = sourceFrame.Bitmap;
                Invoke(new Action(() =>
                {
                    contourPictureBox.Image = decoratedImage.Bitmap;
                }));

            }



                }
        private static void WriteMultilineText(Mat frame, string[] lines, Point origin)
        {
            for (int i = 0; i < lines.Length; i++)
            {
                int y = i * 10 + origin.Y; // Moving down on each line
                CvInvoke.PutText(frame, lines[i], new Point(origin.X, y),
                FontFace.HersheyPlain, 0.8, new Bgr(Color.Red).MCvScalar);
            }
        }
        private void MonitorSerialData()
        {
            while (true)
            {
                // block until \n character is received, extract command data
                string msg = arduinoSerial.ReadLine();
                // confirm the string has both < and > characters
                if (msg.IndexOf("<") == -1 || msg.IndexOf(">") == -1)
                {
                    continue;
                }
                // remove everything before (and including) the < character
                msg = msg.Substring(msg.IndexOf("<") + 1);
                // remove everything after (and including) the > character
                msg = msg.Remove(msg.IndexOf(">"));
                // if the resulting string is empty, disregard and move on
                if (msg.Length == 0)
                {
                    continue;
                }
                // parse the command
                if (msg.Substring(0, 1) == "S")
                {
                    // command is to suspend, toggle states accordingly:
                    ToggleFieldAvailability(msg.Substring(1, 1) == "1");
                }
                else if (msg.Substring(0, 1) == "P")
                {
                    // command is to display the point data, output to the text field:
                    Invoke(new Action(() =>
                    {
                        returnedPointLbl.Text = $"Returned Point Data: {msg.Substring(1)}";
                    }));
                }
            }
        }
        private void ToggleFieldAvailability(bool suspend)
        {
            Invoke(new Action(() =>
            {
                enableCoordinateSending = !suspend;
                lockStateToolStripStatusLabel.Text = $"State: {(suspend ? "Locked" : "Unlocked")}";//Lock the camera until the Arduino sends back the complete command
            }));
        }
        private void ArduinoSerial_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {

        }
    }
    }
        

                               

    
   
    
    
