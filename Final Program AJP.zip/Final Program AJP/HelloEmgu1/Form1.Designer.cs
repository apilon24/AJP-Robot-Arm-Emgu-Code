﻿namespace HelloEmgu1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sourcePictureBox = new System.Windows.Forms.PictureBox();
            this.roiPictureBox = new System.Windows.Forms.PictureBox();
            this.contourPictureBox = new System.Windows.Forms.PictureBox();
            this.lockStateToolStripStatusLabel = new System.Windows.Forms.Label();
            this.returnedPointLbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // sourcePictureBox
            // 
            this.sourcePictureBox.Location = new System.Drawing.Point(12, 3);
            this.sourcePictureBox.Name = "sourcePictureBox";
            this.sourcePictureBox.Size = new System.Drawing.Size(435, 355);
            this.sourcePictureBox.TabIndex = 0;
            this.sourcePictureBox.TabStop = false;
            // 
            // roiPictureBox
            // 
            this.roiPictureBox.Location = new System.Drawing.Point(12, 364);
            this.roiPictureBox.Name = "roiPictureBox";
            this.roiPictureBox.Size = new System.Drawing.Size(435, 265);
            this.roiPictureBox.TabIndex = 1;
            this.roiPictureBox.TabStop = false;
            // 
            // contourPictureBox
            // 
            this.contourPictureBox.Location = new System.Drawing.Point(492, 3);
            this.contourPictureBox.Name = "contourPictureBox";
            this.contourPictureBox.Size = new System.Drawing.Size(443, 355);
            this.contourPictureBox.TabIndex = 2;
            this.contourPictureBox.TabStop = false;
            // 
            // lockStateToolStripStatusLabel
            // 
            this.lockStateToolStripStatusLabel.AutoSize = true;
            this.lockStateToolStripStatusLabel.Location = new System.Drawing.Point(595, 426);
            this.lockStateToolStripStatusLabel.Name = "lockStateToolStripStatusLabel";
            this.lockStateToolStripStatusLabel.Size = new System.Drawing.Size(46, 17);
            this.lockStateToolStripStatusLabel.TabIndex = 14;
            this.lockStateToolStripStatusLabel.Text = "label5";
            // 
            // returnedPointLbl
            // 
            this.returnedPointLbl.AutoSize = true;
            this.returnedPointLbl.Location = new System.Drawing.Point(595, 377);
            this.returnedPointLbl.Name = "returnedPointLbl";
            this.returnedPointLbl.Size = new System.Drawing.Size(46, 17);
            this.returnedPointLbl.TabIndex = 15;
            this.returnedPointLbl.Text = "label5";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1120, 692);
            this.Controls.Add(this.returnedPointLbl);
            this.Controls.Add(this.lockStateToolStripStatusLabel);
            this.Controls.Add(this.contourPictureBox);
            this.Controls.Add(this.roiPictureBox);
            this.Controls.Add(this.sourcePictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox sourcePictureBox;
        private System.Windows.Forms.PictureBox roiPictureBox;
        private System.Windows.Forms.PictureBox contourPictureBox;
        private System.Windows.Forms.Label lockStateToolStripStatusLabel;
        private System.Windows.Forms.Label returnedPointLbl;
    }
}

